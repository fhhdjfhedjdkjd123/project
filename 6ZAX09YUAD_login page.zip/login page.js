let textEleFiled = document.getElementById("textEle");
let emailEle = document.getElementById("emailErrorMessage");
let passwordEleField = document.getElementById("passwordEle");
let passwordEle = document.getElementById("passwordErrorMessage");
let loginButtonEle = document.getElementById("loginButton");
let errormsgEle = document.getElementById("errorMsg");

loginButtonEle.onclick = function() {
    let inputVal = textEleFiled.value;
    let passwordVal = passwordEleField.value;

};